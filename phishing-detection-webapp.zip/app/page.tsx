import { CheckCircle, AlertTriangle, ExternalLink } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { UrlCheckForm } from "@/components/url-check-form"
import { ModelMetrics } from "@/components/model-metrics"
import { FeatureImportance } from "@/components/feature-importance"
import { HowItWorks } from "@/components/how-it-works"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="mr-4 flex">
            <Link href="/" className="flex items-center space-x-2">
              <AlertTriangle className="h-6 w-6 text-red-500" />
              <span className="font-bold">PhishGuard</span>
            </Link>
          </div>
          <nav className="flex flex-1 items-center justify-end space-x-4">
            <Link href="#features" className="text-sm font-medium">
              Features
            </Link>
            <Link href="#how-it-works" className="text-sm font-medium">
              How It Works
            </Link>
            <Link href="#about" className="text-sm font-medium">
              About
            </Link>
            <Button variant="default">
              <Link href="https://github.com/MEENUPARAMES" className="flex items-center gap-1">
                <span>GitHub</span>
                <ExternalLink className="h-4 w-4" />
              </Link>
            </Button>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-background to-muted">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                    Protect Yourself From Phishing Attacks
                  </h1>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    Our advanced machine learning model detects phishing websites with 96.97% accuracy. Check any
                    suspicious URL before you visit.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button className="px-8">
                    <Link href="#check-url">Check URL Now</Link>
                  </Button>
                  <Button variant="outline">
                    <Link href="#how-it-works">Learn More</Link>
                  </Button>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <Card className="w-full">
                  <CardHeader>
                    <CardTitle>URL Security Check</CardTitle>
                    <CardDescription>Enter a URL to check if it's a potential phishing site</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <UrlCheckForm />
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        <section id="features" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Key Features</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  Our phishing detection system uses advanced machine learning techniques to identify malicious websites
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-3">
              <Card>
                <CardHeader className="flex flex-row items-center gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                    <CheckCircle className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>High Accuracy</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>Our model achieves 96.97% accuracy in detecting phishing websites using multiple features.</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                    <AlertTriangle className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Real-time Detection</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>Get instant results when checking URLs, with detailed explanations of potential threats.</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                    <ExternalLink className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>URL Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>Comprehensive analysis of URL structure, domain age, SSL certificates, and content patterns.</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section id="how-it-works" className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">How It Works</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  Our machine learning model analyzes various features to determine if a website is legitimate or
                  phishing
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-5xl py-12">
              <HowItWorks />
            </div>
          </div>
        </section>

        <section id="model-performance" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Model Performance</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  Our model has been trained and tested on thousands of websites to ensure high accuracy
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-5xl py-12">
              <Tabs defaultValue="metrics" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="metrics">Performance Metrics</TabsTrigger>
                  <TabsTrigger value="features">Feature Importance</TabsTrigger>
                </TabsList>
                <TabsContent value="metrics" className="p-4">
                  <ModelMetrics />
                </TabsContent>
                <TabsContent value="features" className="p-4">
                  <FeatureImportance />
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </section>

        <section id="about" className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
              <div className="space-y-4">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">About the Project</h2>
                <p className="text-muted-foreground">
                  This phishing website detection system was developed as part of my B.Tech in Artificial Intelligence
                  and Data Science. The project uses machine learning techniques to analyze URLs, website content, and
                  behavioral indicators to detect and block phishing attempts in real-time.
                </p>
                <p className="text-muted-foreground">
                  The model can be integrated into web browsers or security tools to enhance user protection, delivering
                  high accuracy in identifying and preventing access to malicious websites.
                </p>
              </div>
              <div className="space-y-4">
                <h3 className="text-xl font-bold">About the Developer</h3>
                <div className="space-y-2">
                  <h4 className="font-medium">Meenu Parames P</h4>
                  <p className="text-muted-foreground">
                    B.Tech in Artificial Intelligence and Data Science from SNS College of Engineering, Coimbatore.
                    Skilled in Python, Machine Learning, Deep Learning, and Data Analysis.
                  </p>
                  <div className="flex gap-4">
                    <Button variant="outline" size="sm">
                      <Link href="https://linkedin.com/in/meenuparames" className="flex items-center gap-1">
                        <span>LinkedIn</span>
                        <ExternalLink className="h-4 w-4" />
                      </Link>
                    </Button>
                    <Button variant="outline" size="sm">
                      <Link href="https://github.com/MEENUPARAMES" className="flex items-center gap-1">
                        <span>GitHub</span>
                        <ExternalLink className="h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t py-6">
        <div className="container flex flex-col items-center justify-center gap-4 md:flex-row md:gap-8">
          <p className="text-center text-sm text-muted-foreground md:text-left">
            © 2025 PhishGuard. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="#" className="text-sm text-muted-foreground hover:underline">
              Terms of Service
            </Link>
            <Link href="#" className="text-sm text-muted-foreground hover:underline">
              Privacy Policy
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
