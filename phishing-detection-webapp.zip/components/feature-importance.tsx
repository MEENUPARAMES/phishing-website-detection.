"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Chart } from "@/components/ui/chart"
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts"

export function FeatureImportance() {
  // Sample feature importance data (you would replace this with your actual model's feature importance)
  const featureImportanceData = [
    { name: "URL Length", importance: 0.092 },
    { name: "Has IP Address", importance: 0.087 },
    { name: "Domain Age", importance: 0.085 },
    { name: "SSL Certificate", importance: 0.082 },
    { name: "Subdomain Count", importance: 0.078 },
    { name: "Has @ Symbol", importance: 0.075 },
    { name: "Redirect Count", importance: 0.072 },
    { name: "URL Shortening", importance: 0.068 },
    { name: "Has Hyphen", importance: 0.065 },
    { name: "Double Slash", importance: 0.062 },
  ].sort((a, b) => b.importance - a.importance)

  return (
    <Card>
      <CardHeader>
        <CardTitle>Feature Importance</CardTitle>
        <CardDescription>
          The relative importance of each feature in the model's decision-making process
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[400px]">
          <Chart>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={featureImportanceData}
                layout="vertical"
                margin={{ top: 5, right: 30, left: 100, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" domain={[0, Math.max(...featureImportanceData.map((d) => d.importance)) * 1.1]} />
                <YAxis type="category" dataKey="name" />
                <Tooltip formatter={(value) => [(value * 100).toFixed(2) + "%", "Importance"]} />
                <Legend />
                <Bar dataKey="importance" fill="#1e40af" name="Importance Score" />
              </BarChart>
            </ResponsiveContainer>
          </Chart>
        </div>
      </CardContent>
    </Card>
  )
}
