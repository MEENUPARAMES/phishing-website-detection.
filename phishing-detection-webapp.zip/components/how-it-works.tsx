import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, Database, FileText, AlertTriangle, Cpu } from "lucide-react"

export function HowItWorks() {
  const steps = [
    {
      icon: <FileText className="h-8 w-8 text-primary" />,
      title: "URL Analysis",
      description:
        "The system extracts features from the URL such as length, presence of special characters, domain age, and more.",
    },
    {
      icon: <Database className="h-8 w-8 text-primary" />,
      title: "Feature Extraction",
      description:
        "Over 30 different features are extracted and normalized to be used as input for the machine learning model.",
    },
    {
      icon: <Cpu className="h-8 w-8 text-primary" />,
      title: "Model Processing",
      description:
        "Our trained machine learning model processes the features to determine if the website is legitimate or phishing.",
    },
    {
      icon: <CheckCircle className="h-8 w-8 text-primary" />,
      title: "Result Classification",
      description: "The model classifies the URL as either legitimate or phishing with a confidence score.",
    },
    {
      icon: <AlertTriangle className="h-8 w-8 text-primary" />,
      title: "User Alert",
      description:
        "Users are alerted if a potential phishing site is detected, with details about the suspicious features.",
    },
  ]

  return (
    <div className="space-y-8">
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {steps.map((step, index) => (
          <Card key={index} className="flex flex-col">
            <CardHeader className="flex flex-row items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">{step.icon}</div>
              <div>
                <CardTitle>Step {index + 1}</CardTitle>
                <CardDescription>{step.title}</CardDescription>
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              <p>{step.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Technical Implementation</CardTitle>
          <CardDescription>How the machine learning model works behind the scenes</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p>
              The phishing detection system uses a machine learning model trained on a dataset of over 2,000 websites,
              with features extracted from both legitimate and phishing URLs.
            </p>
            <p>
              The model achieves 96.97% accuracy by analyzing patterns in URL structure, domain information, HTML and
              JavaScript content, and other web security indicators.
            </p>
            <p>Key technologies used in the implementation include:</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Python for backend processing and model training</li>
              <li>Scikit-learn for machine learning algorithms</li>
              <li>Next.js for the web application frontend</li>
              <li>API endpoints for real-time URL checking</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
