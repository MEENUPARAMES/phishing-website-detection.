"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Chart } from "@/components/ui/chart"
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts"

export function ModelMetrics() {
  const metricsData = [
    { name: "Accuracy", value: 96.97 },
    { name: "Precision", value: 97.0 },
    { name: "Recall", value: 97.0 },
    { name: "F1-Score", value: 97.0 },
  ]

  const classificationData = [
    { class: "Legitimate (-1)", precision: 0.97, recall: 0.96, f1Score: 0.97, support: 979 },
    { class: "Phishing (1)", precision: 0.97, recall: 0.98, f1Score: 0.97, support: 1232 },
  ]

  const confusionMatrix = [
    { name: "True Negative", value: 940 },
    { name: "False Positive", value: 39 },
    { name: "False Negative", value: 25 },
    { name: "True Positive", value: 1207 },
  ]

  return (
    <div className="space-y-8">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {metricsData.map((metric) => (
          <Card key={metric.name}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{metric.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{metric.value}%</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Classification Report</CardTitle>
          <CardDescription>Detailed performance metrics for each class</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Class</TableHead>
                <TableHead>Precision</TableHead>
                <TableHead>Recall</TableHead>
                <TableHead>F1-Score</TableHead>
                <TableHead>Support</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {classificationData.map((row) => (
                <TableRow key={row.class}>
                  <TableCell className="font-medium">{row.class}</TableCell>
                  <TableCell>{row.precision}</TableCell>
                  <TableCell>{row.recall}</TableCell>
                  <TableCell>{row.f1Score}</TableCell>
                  <TableCell>{row.support}</TableCell>
                </TableRow>
              ))}
              <TableRow>
                <TableCell className="font-medium">Total</TableCell>
                <TableCell>0.97</TableCell>
                <TableCell>0.97</TableCell>
                <TableCell>0.97</TableCell>
                <TableCell>2211</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Confusion Matrix</CardTitle>
          <CardDescription>Visualization of model predictions vs actual values</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <Chart>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={confusionMatrix}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="value" fill="#1e40af" />
                </BarChart>
              </ResponsiveContainer>
            </Chart>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
