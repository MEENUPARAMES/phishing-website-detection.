"use client"

import type React from "react"

import { useState } from "react"
import { AlertCircle, CheckCircle, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { checkUrl } from "@/lib/actions"

export function UrlCheckForm() {
  const [url, setUrl] = useState("")
  const [result, setResult] = useState<null | {
    isPhishing: boolean
    confidence: number
    features: Record<string, any>
  }>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      // Validate URL format
      if (!url.match(/^(http|https):\/\/[a-zA-Z0-9-_.]+\.[a-zA-Z]{2,}(\/.*)?$/)) {
        throw new Error("Please enter a valid URL (e.g., https://example.com)")
      }

      const checkResult = await checkUrl(url)
      setResult(checkResult)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred while checking the URL")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <form onSubmit={handleSubmit} className="flex w-full max-w-sm items-center space-x-2">
        <Input
          type="text"
          placeholder="Enter URL (e.g., https://example.com)"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          className="flex-1"
        />
        <Button type="submit" disabled={loading}>
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Check"}
        </Button>
      </form>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {result && (
        <Alert variant={result.isPhishing ? "destructive" : "default"}>
          {result.isPhishing ? <AlertCircle className="h-4 w-4" /> : <CheckCircle className="h-4 w-4" />}
          <AlertTitle>{result.isPhishing ? "Potential Phishing Site Detected!" : "Safe Website"}</AlertTitle>
          <AlertDescription>
            <div className="mt-2">
              <p>
                {result.isPhishing
                  ? "This URL shows characteristics of a phishing website. Be careful!"
                  : "This URL appears to be legitimate."}
              </p>
              <p className="mt-1">Confidence: {(result.confidence * 100).toFixed(2)}%</p>

              {result.isPhishing && (
                <div className="mt-2">
                  <p className="font-semibold">Suspicious features:</p>
                  <ul className="list-disc pl-5 text-sm">
                    {result.features.hasIpAddress && <li>Uses IP address in URL</li>}
                    {result.features.longUrl && <li>Unusually long URL</li>}
                    {result.features.shorteningService && <li>Uses URL shortening service</li>}
                    {result.features.hasAtSymbol && <li>Contains @ symbol in URL</li>}
                    {result.features.doubleSlashRedirect && <li>Double slash redirect</li>}
                    {result.features.prefixSuffix && <li>Prefix/suffix with hyphen</li>}
                    {result.features.noHttps && <li>No HTTPS/SSL</li>}
                  </ul>
                </div>
              )}
            </div>
          </AlertDescription>
        </Alert>
      )}
    </div>
  )
}
